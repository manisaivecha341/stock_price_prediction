#Run each individual dataset individually by using the stocker.py file and you can derive the results and graphs


from stocker import Stocker
#TATA CONSULTANCY SERVICES -TCS
tcs=Stocker('TCS')
tcs.plot_stock()
tcs.evaluate_predicton()
tcs.changepoint_prior_analysis((changepoint_priors=[0.001, 0.005, 0.1, 0.2]))
#to visualize the test errors and select the minimizing testerror
tcs.changepoint_prior_scale=0.005
#to minimize the training error using test error
model,model_data=tcs.create_prophet_model(days=42)
#to predict the prize of the stock on 16th May

#WIPRO PRIVATE LTD.

wpr=Stocker('WIPRO')
wpr.plot_stock()
wpr.evaluate_predicton()
wpr.changepoint_prior_analysis((changepoint_priors=[0.001, 0.005, 0.1, 0.2]))
#to visualize the test errors and select the minimizing testerror
wpr.changepoint_prior_scale=0.2
#to minimize the training error using test error
model,model_data=wpr.create_prophet_model(days=42)
#to predict the prize of the stock on 16th May

#AXISBANK PVT.LTD.

axis=Stocker('AXISBANK')
axis.plot_stock()
axis.evaluate_predicton()
axis.changepoint_prior_analysis((changepoint_priors=[0.001, 0.05, 0.1, 0.2]))
#to visualize the test errors and select the minimizing testerror
axis.changepoint_prior_scale=0.1
#to minimize the training error using test error
model,model_data=axis.create_prophet_model(days=42)
#to predict the prize of the stock on 16th May

#HCL TECHNOLOGIES
hcl=Stocker('HCLTECH')
hcl.plot_stock()
hcl.evaluate_predicton()
hcl.changepoint_prior_analysis((changepoint_priors=[0.001, 0.005, 0.1, 0.2]))
#to visualize the test errors and select the minimizing testerror
hcl.changepoint_prior_scale=0.1
#to minimize the training error using test error
model,model_data=hcl.create_prophet_model(days=42)
#to predict the prize of the stock on 16th May

#HDFC BANK PVT.LTD.
hdfc=Stocker('HDFCBANK')
hdfc.plot_stock()
hdfc.evaluate_predicton()
hdfc.changepoint_prior_analysis((changepoint_priors=[0.1, 0.5, 0.4, 0.2]))
#to visualize the test errors and select the minimizing testerror
hdfc.changepoint_prior_scale=0.4
#to minimize the training error using test error
model,model_data=hdfc.create_prophet_model(days=42)

#ICICI BANK PVT.LTD.
icici=Stocker('ICICIBANK')
icici.plot_stock()
icici.evaluate_predicton()
icici.changepoint_prior_analysis((changepoint_priors=[0.1, 0.5, 0.4, 0.2,0.15]))
#to visualize the test errors and select the minimizing testerror
icici.changepoint_prior_scale=0.15
#to minimize the training error using test error
model,model_data=icici.create_prophet_model(days=42)

#INDUSLAND BANK PRIVATE LTD.
inds=Stocker('INDUSINDBK')
inds.plot_stock()
inds.evaluate_predicton()
inds.changepoint_prior_analysis((changepoint_priors=[0.1, 0.5, 0.4, 0.2,0.15,0.005,0.01]))
#to visualize the test errors and select the minimizing testerror
inds.changepoint_prior_scale=0.005
#to minimize the training error using test error
model,model_data=inds.create_prophet_model(days=42)


#INFOSYS PVT.LTD.
infy=Stocker('INFY')
infy.plot_stock()
infy.evaluate_predicton()
infy.changepoint_prior_analysis((changepoint_priors=[0.1, 0.5, 0.4, 0.2,0.15,0.005,0.01]))
#to visualize the test errors and select the minimizing testerror
inds.changepoint_prior_scale=0.15
#to minimize the training error using test error
model,model_data=infy.create_prophet_model(days=42)

#KOTAK MAHINDRA BANK 
kotak=Stocker('KOTAKBANK')
kotak.plot_stock()
kotak.evaluate_predicton()
kotak.changepoint_prior_analysis((changepoint_priors=[0.1, 0.5, 0.4, 0.2,0.15,0.005,0.01]))
#to visualize the test errors and select the minimizing testerror
kotak.changepoint_prior_scale=0.1
#to minimize the training error using test error
model,model_data=kotak.create_prophet_model(days=42)

#STATE BANK OF INDIA-SBI
sbi=Stocker('SBIN')
sbi.plot_stock()
sbi.evaluate_predicton()
sbi.changepoint_prior_analysis((changepoint_priors=[0.1, 0.5, 0.4, 0.2,0.15,0.005,0.01]))
#to visualize the test errors and select the minimizing testerror
sbi.changepoint_prior_scale=0.4
#to minimize the training error using test error
model,model_data=sbi.create_prophet_model(days=42)

#YESBANK PVT.LTD.
yb=Stocker('YESBANK')
yb.plot_stock()
yb.evaluate_predicton()
yb.changepoint_prior_analysis((changepoint_priors=[0.1, 0.5, 0.4, 0.2,0.15,0.005,0.01]))
#to visualize the test errors and select the minimizing testerror
yb.changepoint_prior_scale=0.005
#to minimize the training error using test error
model,model_data=yb.create_prophet_model(days=42)

#TECH MAHINDRA PVT.LTD.
techm=Stocker('TECHM')
techm.plot_stock()
techm.evaluate_predicton()
techm.changepoint_prior_analysis((changepoint_priors=[0.1, 0.5, 0.4, 0.2,0.15,0.005,0.01]))
#to visualize the test errors and select the minimizing testerror
techm.changepoint_prior_scale=0.1
#to minimize the training error using test error
model,model_data=techm.create_prophet_model(days=42)
